extends CharacterBody2D

@export var velocidade = 100.0
@export var vida = 3
@export var distancia_ataque = 35.0
@export var dano = 1
@onready var jogador = get_tree().get_first_node_in_group("jogador")
@onready var timer_ataque = $TimerAtaque


func _physics_process(_delta):
	if jogador == null:
		return

	if jogador.vida <= 0:
		velocity = Vector2.ZERO
		return

	var distancia = global_position.distance_to(jogador.global_position)

	if distancia > distancia_ataque:
		var direcao = (jogador.global_position - global_position).normalized()
		velocity = direcao * velocidade
	else:
		velocity = Vector2.ZERO

		if timer_ataque.is_stopped():
			jogador.receber_dano(dano)
			timer_ataque.start()

	move_and_slide()


func receber_dano(dano):
	if vida <= 0:
		return

	vida -= dano
	print("Inimigo atingido! Vida restante: ", vida)

	if vida <= 0:
		queue_free()
