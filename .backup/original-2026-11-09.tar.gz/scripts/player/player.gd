extends CharacterBody2D

@export var velocidade = 200.0
@export var cena_projetil: PackedScene
@export var intervalo_tiro = 0.3
@export var vida = 5
@onready var timer_invencibilidade = $TimerInvencibilidade

@onready var timer_tiro = $TimerTiro

var direcao_olhar = 1
var bloqueado = false

func _physics_process(_delta):
	if vida <= 0 or bloqueado:
		velocity = Vector2.ZERO
		return

	# MOVIMENTAÇÃO
	var direcao = Input.get_vector(
		"mover_esquerda",
		"mover_direita",
		"mover_cima",
		"mover_baixo"
	)
	velocity = direcao * velocidade
	move_and_slide()

	# DIREÇÃO DO PERSONAGEM
	if direcao.x > 0:
		direcao_olhar = 1
	elif direcao.x < 0:
		direcao_olhar = -1

	# ATAQUE
	if Input.is_action_pressed("atirar") and timer_tiro.is_stopped():
		atirar()
		timer_tiro.start()


func atirar():
	if cena_projetil == null:
		return

	var projetil = cena_projetil.instantiate()
	projetil.direcao = direcao_olhar

	get_tree().current_scene.add_child(projetil)

	projetil.global_position = global_position + Vector2(25 * direcao_olhar, 0)

func receber_dano(dano):
	if vida <= 0 or not timer_invencibilidade.is_stopped():
		return

	vida -= dano
	print("Dylan levou dano! Vida atual: ", vida)

	if vida <= 0:
		morrer()
	else:
		timer_invencibilidade.start()


func morrer():
	vida = 0
	velocity = Vector2.ZERO
	print("GAME OVER")
	print("Pressione R para reiniciar")
