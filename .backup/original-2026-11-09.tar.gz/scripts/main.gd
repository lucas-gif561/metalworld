extends Node2D

@export var quantidade_arenas = 3
@export var duracao_transicao = 0.8
@export var margem_superior = 310.0
@export var margem_inferior = 80.0
@onready var player = $Player
@onready var camera = $Camera2D
@onready var enemy_manager = $EnemyManager
@onready var portal = $Portal


var fase_concluida = false
var arena_atual = 1
var em_transicao = false
var largura_tela = 0.0
var altura_tela = 0.0

func _ready():
	largura_tela = get_viewport_rect().size.x / camera.zoom.x
	altura_tela = get_viewport_rect().size.y / camera.zoom.y

	print("Arena atual: ", arena_atual)


func _process(_delta):
	if em_transicao or player.vida <= 0 or fase_concluida:
		return

	# VERIFICAR FIM DA FASE
	if arena_atual == quantidade_arenas and enemy_manager.arena_liberada:
		concluir_fase()
		return

	# LIMITES DA ARENA
	var borda_direita = camera.global_position.x + largura_tela / 2.0 - 40
	var borda_esquerda = camera.global_position.x - largura_tela / 2.0 + 40

	var borda_superior = camera.global_position.y - altura_tela / 2.0 + margem_superior
	var borda_inferior = camera.global_position.y + altura_tela / 2.0 - margem_inferior

	# LIMITES VERTICAIS
	player.global_position.y = clampf(
		player.global_position.y,
		borda_superior,
		borda_inferior
	)

	# LIMITE ESQUERDO
	if player.global_position.x < borda_esquerda:
		player.global_position.x = borda_esquerda

	# LIMITE DIREITO
	if player.global_position.x >= borda_direita:
		player.global_position.x = borda_direita

		if arena_atual < quantidade_arenas and enemy_manager.arena_liberada:
			proxima_arena()


func proxima_arena():
	em_transicao = true
	player.bloqueado = true

	print("Indo para a próxima arena...")

	var distancia = largura_tela - 120
	var destino = camera.global_position + Vector2(distancia, 0)

	var tween = create_tween()

	tween.tween_property(
		camera,
		"global_position",
		destino,
		duracao_transicao
	)

	await tween.finished

	arena_atual += 1

	# GERA OS INIMIGOS DA NOVA ARENA
	enemy_manager.iniciar_arena(arena_atual)

	em_transicao = false
	player.bloqueado = false

	print("Arena atual: ", arena_atual)

func _input(event):
	if player.vida <= 0 and event.is_action_pressed("reiniciar"):
		enemy_manager.reiniciando = true
		get_tree().call_deferred("reload_current_scene")

func concluir_fase():
	fase_concluida = true

	player.bloqueado = false
	player.velocity = Vector2.ZERO
	
	portal.ativar_portal()
	
	print("====================")
	print("FASE CONCLUÍDA!")
	print("Todas as arenas foram finalizadas")
	print("agora é RIFF MODE papai!")
	print("====================")
