extends Control

@export var velocidade: float = 150.0

@onready var seta = $Seta

var coluna: int = 0
var acertada = false


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	atualizar_seta()
	pass # Replace with function body.
	
func atualizar_seta():
	var simbolos = ["↑", "↓", "←", "→"]
	seta.text = simbolos[coluna]


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y += velocidade * delta
	
	if position.y >= 290 and not acertada:
		acertada = true
		print("Miss")
		queue_free()
	pass
