extends Node2D

@onready var boss = $Arena/Boss
@onready var boss_health_bar = $HUD/BossHealthBar
@onready var jogador = $Player
@onready var riff_hud = $HUD/RiffHUD

var riff_ativo = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	boss.jogador = jogador
	
	boss_health_bar.max_value = boss.vida_maxima
	boss_health_bar.value = boss.vida_atual
	boss.vida_atualizada.connect(_atualizar_barra_boss)
	boss.ciclo_ataques()
	riff_hud.hide()
	pass # Replace with function body.
	
func _atualizar_barra_boss(vida):
	boss_health_bar.value = vida
	
	if vida <= 0:
		riff_ativo = false
		riff_hud.parar_riff()
		riff_hud.hide()
		jogador.bloqueado = false
		print("Boss derrotado!! Riff Mode encerrado")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if jogador.vida <= 0:
		if riff_ativo:
			riff_ativo = false
			riff_hud.parar_riff()
			riff_hud.hide()
			
		if Input.is_key_pressed(KEY_R):
			get_tree().reload_current_scene()
		
	if Input.is_action_just_pressed("riff_mode") and boss.vida_atual > 0:
		riff_ativo = not riff_ativo
		jogador.bloqueado = riff_ativo
		riff_hud.visible = riff_ativo
		
		if riff_ativo:
			riff_hud.iniciar_riff()
			print("Riff Mode ativado!")
		else:
			riff_hud.parar_riff()
			print("Riff Mode desativado!")
	pass
