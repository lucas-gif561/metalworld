extends Node2D

@export var cena_ataque_area: PackedScene
@export var cena_projetil: PackedScene
@export var jogador: Node2D
@export var vida_maxima: int = 100

var atacando: bool = false
var vida_atual: int

signal vida_atualizada(vida)


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	vida_atual = vida_maxima

func receber_dano(valor: int):
	if vida_atual <= 0:
		return
	vida_atual -= valor
	vida_atual = max(vida_atual, 0)
	vida_atualizada.emit(vida_atual)
	
	print("Vida do Boss: ", vida_atual)
	
	if vida_atual <= 0:
		morrer()
		
func morrer():
	print("Boss derrotado!")
	
func iniciar_rajada():
	if atacando:
		return
		
	if jogador == null or cena_projetil == null:
		return
		
	atacando = true
	
	for i in range(6):
		if not jogador_vivo():
			break
			
		var projetil = cena_projetil.instantiate()
		get_parent().add_child(projetil)
		
		projetil.global_position = global_position
		projetil.direcao = (jogador.global_position - global_position). normalized()
		
		await get_tree().create_timer(0.4).timeout
	
	atacando = false
	print("Rajada Finalizada")
	
func ataque_leque():
	if atacando or jogador == null or cena_projetil == null:
		return
		
	atacando = true
	
	var direcao_central = (jogador.global_position - global_position).normalized()
	
	for angulo in [-40, -20, 0, 20, 40]:
		if not jogador_vivo():
			break
			
		var projetil = cena_projetil.instantiate()
		get_parent().add_child(projetil)
		
		projetil.global_position = global_position
		projetil.direcao = direcao_central.rotated(deg_to_rad(angulo))
		
	atacando = false
	
func ataque_area():
	if atacando or not jogador_vivo() or cena_ataque_area == null:
		return
		
	atacando = true
	
	var area = cena_ataque_area.instantiate()
	get_parent().add_child(area)
	
	area.global_position = jogador.global_position
	
	await get_tree().create_timer(1.5).timeout
	
	atacando = false
	
func ciclo_ataques():
	await get_tree().create_timer(2.0).timeout
	
	while vida_atual > 0 and jogador_vivo():
		
		iniciar_rajada()
		
		while atacando:
			await get_tree().process_frame
			
		await get_tree().create_timer(2.0).timeout
		
		if vida_atual <= 0:
			break
		
		for i in range(3):
			ataque_leque()
			
			if i < 2:
				await get_tree().create_timer(0.7).timeout
		
		await get_tree().create_timer(2.0).timeout
		
		if vida_atual <= 0:
			break
			
		for i in range(4):
			ataque_area()
			
			while atacando:
				await get_tree().process_frame
				
			if i < 3:
				await get_tree().create_timer(0.5).timeout
				
		if not jogador_vivo():
			break
			
		await get_tree().create_timer(5.0).timeout
		
		
func jogador_vivo() -> bool:
	return is_instance_valid(jogador) and jogador.vida > 0

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
