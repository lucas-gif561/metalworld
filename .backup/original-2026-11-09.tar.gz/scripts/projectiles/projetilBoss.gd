extends Area2D

@export var velocidade: float = 250.0
@export var dano: int = 1

var direcao: Vector2 = Vector2.RIGHT


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	body_entered.connect(_ao_colidir)
	pass # Replace with function body.
	
func _physics_process(delta):
	global_position += direcao * velocidade * delta
	
func _ao_colidir(corpo):
	if corpo.is_in_group("jogador"):
		corpo.receber_dano(dano)
		queue_free()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	global_position += direcao * velocidade * delta
	pass
