extends Area2D

@export var velocidade = 350.0
@export var alcance = 550.0
@export var dano = 2

var direcao = 1
var distancia = 0.0


func _ready():
	body_entered.connect(atingir)


func _physics_process(delta):
	var movimento = velocidade * delta

	position.x += movimento * direcao
	distancia += movimento

	if distancia >= alcance:
		queue_free()


func atingir(corpo):
	if corpo.is_in_group("jogador"):
		corpo.receber_dano(dano)
		queue_free()
